# Molecular Docking Automation Pipeline

This project automates molecular docking of ligands with *S. aureus* DHFR protein using AutoDock Vina and Python.

## Features
- Batch docking of triazine analogues
- Parses best binding affinity
- Grid preset for 3FRA PDB (26.587, 14.104, 43.568)

## Usage
1. Place `.pdbqt` ligands in `ligands/` folder
2. Put prepared receptor file in `receptor/3FRA.pdbqt`
3. Run: `python docking_pipeline.py`
4. Results will be saved in `docking_results/`

## Author
Uvais Raza
